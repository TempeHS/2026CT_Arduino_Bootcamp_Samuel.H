#Samuel's Distance
My system will read when the button (Pretending it to be a doorbell) is pressed it will be read by the buzzer. The buzzer will then proceed to make a sound, notifying the user someone is pressing the button (or at the door). This will then be transmitted to the OLED scren and show that the button has been pressed, as a state of ON or OFF. 


## Sensors being used:
| Sensor | Use | Pin |
| --- | --- | --- |
| 1x OLED Screen | Show a Value | I2C |
| 1x Buzzer | To Make Noise | 3 |
| 1x Button | To tell when its pressed | 6 |

### Not sensors being used:

1. 1x Arduino Sensor Kit Base
2. 3x Wires
3. 1x Connection Wire USB-C to Micro-B

#### My Pseudocode

BEGIN

Setup Buzzer
Setup OLED
Setup Button

WHILE Power is ON:
    READ Button

    IF State is ON:
        // Alert (1)
        Turn Buzzer ON
        END
    ELSE:
        // Alert (2)
        Display message on OLED Screen
        END

END
